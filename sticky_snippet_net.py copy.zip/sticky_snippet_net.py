'''
python sticky_snippet_net.py mode model_file data_folder
'''

import os
import sys
import tensorflow as tf
import numpy as np

#global variables
mode_fun = None
model_file = None
data_folder = None

def getLabel(dna):
    i , j = 0, 39
    while( i < j):
        if (dna[i] == dna[j]):
            i += 1
            j -= 1
            continue
        break
    return (i+1)(i+2)

def training():
    return 0

def fivefold_training():
    return 0

def testing():
    return 0

mode = {
    "train": training,
    "5fold": fivefold_training,
    "test": testing
}

def print_help():
    print "python sticky_snippet_net.py mode model_file data_folder"

def parse_args():
    print sys.argv
    global mode_fun, model_file, data_folder
    mode_fun = mode[sys.argv[1]]
    model_file = str(sys.argv[2])
    data_folder = str(sys.argv[3])

if __name__ == "__main__":
    if (len(sys.argv) != 4):
        print "Invalid arguments"
        print_help()
    else:
        parse_args()

    mode_fun()